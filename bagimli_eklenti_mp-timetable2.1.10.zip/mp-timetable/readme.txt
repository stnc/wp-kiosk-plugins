=== Timetable and Event Schedule by MotoPress ===
Contributors: MotoPress
Donate link: https://motopress.com/
Tags: schedule,timetable,event management,calendar,event calendar,event categories,organizer,classes,gym,school,scheduler,table
Requires at least: 3.8
Tested up to: 4.8
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Smart event organizer and time-management tool with a clean minimalist design for featuring your timetables and upcoming events.

== Description ==
MotoPress Timetable and Event Schedule is an all-around organizer plugin developed to help you create and manage online schedules for a single or multiple events, customize the appearance of each event, add date, time, description and display all the needed items in a carefully-crafted timetable. It also comes with Upcoming events widget that will help you keep the sidebar clutter-free. The plugin can be used for timetabling different types of events like various lessons, gym classes, festivals, conferences, ceremonies, case-studies, formal parties, concerts, and much more. It's handy in terms of backend management and maximum easy for your audience to use.

* Check [Timetable and Event Schedule Plugin Demo](https://mpttdemo.getmotopress.com/)
* Please find the step-by-step instructions of working with the plugin [here](https://motopress.com/files/motopress-timetable-plugin-documentation.pdf)

= Key advantages =

**Responsive design.** It's optimized to be viewed perfectly on different devices. A good step forward, the plugin was supplied with the ability to manually adjust the way to show your timetable on mobile devices and desktops.

**A well thought-out toolkit of shortcode settings.** It eliminates the difficulties of timetabling as all preferable settings can be applied in minutes. Each setting is supplied with sufficient clarifications to ensure you coordinate and edit your events fast without additional help.   

**Handy event filtering.** The visitors can filter the timetable to display the only events they are interested in.

**Color controls.** Highlight important activities by presenting them in different colors. Additionally, it simplifies and speeds up the search as the needed events marked with the same color can be noticed faster even without being filtered. Various color markers can become helpful in making the timetable more colorful or in customizing it to fit your website color scheme.

**More precise visual time frames.** Hourly time frames are generally large enough for showing the events, but using the MotoPress Timetable plugin you still can increase them by setting the timetable to show up to 15 minutes accurate time in the left 'time' column.  

**Flexibility.** If any unexpected delays or total dates' changes take place, your timetable can bend easily in one direction or another thanks to a couple of qucik time edits in the backend.

= Main features =
* Several column types
* Selecting/deselecting the preferable columns and events to be displayed in the timetable
* Ability to add event tags and categories
* Ability to display the events by the appropriate categories
* Hour measure to be displayed in the left timetable column to show more accurate duration of each activity (event)
* Several filter styles: drop-down list and tabs
* Option to display/hide 'All Events' view mode, hours column and empty rows
* Customizable event parameters (title, time, subtitle, etc.) and the ability to display only preferable ones in the timetable
* Featured images for individual events
* Opportunity to set event URL to link it any external website
* Text align options for event blocks
* Unique IDs for multiple timetables on a single page
* Color settings for background, background hover, text, and text hover
* Export/import of your data

== Installation ==

1. Upload the plugin files to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress. You'll find 'Timetable' on your main WordPress dashboard.  

== Screenshots ==
1. Timetable
2. Column
3. Timeslots

== Credits ==

Plugin bundles the following third-party resources:

* GUMP, Copyright (c) 2015 wixelhq.com, MIT License
* jQuery UI, Copyright (c) 2013 jQuery Foundation and other contributors Licensed MIT
* Spectrum Colorpicker, by Brian Grinstead, MIT License
* jBox, by Stephan Wagner, MIT License
* jQuery UI Timepicker, Copyright 2010-2013, Francois Gelinas, Dual licensed under the MIT or GPL Version 2 licenses.


== Changelog ==

= 2.1.10 =
* Improved compatibility with WooCommerce Memberships plugin.
* Better W3C validation.

= 2.1.9 =
* Bug fix: fixed the issue when event was not visible in the timetable if it starts at 00:00.

= 2.1.8 =
* Improved compatibility with javascript-disabled browsers.

= 2.1.7 =
* Bug fix: fixed the issue when events were not filtered by the selected category in a widget.
* Bug fix: fixed the issue when event was not visible in the timetable if it ends the next day.
* Minor bugfixes and improvements.

= 2.1.6 =
* New dashboard icons.

= 2.1.5 =
* Bug fix: fixed the issue when table is not visible if events filter is set to 'none'.

= 2.1.4 =
* Bug fix: fixed internal issue.

= 2.1.3 =
* Added the ability to merge cells with common events.
* Added the ability to set vertical alignment in the table.
* Added the ability to set custom CSS class for table shortcode.
* Added the ability to hide filter control on the top of the table.
* Bug fix: fixed the issue when table ID didn't output on the site.

= 2.1.2 =
* Bug fix: fixed the issue when plugin overrides default archive template.
* Bug fix: fixed the issue in upcoming events widget when events were not sorted by days.

= 2.1.1 =
* Bug fix: fixed the issue with shortcode tempalte.

= 2.1.0 =
* Added the ability to override templates in a theme. 
* Bug fix: fixed the issue on WordPress multisite when Event wasn't saving. 
* Bug fix: fixed the issue when timeslots didn't show if Event is in the Draft status.

= 2.0.4 =
* Bug fix: fixed an issue with post template on search results page.

= 2.0.3 =
* Bug fix: fixed a link to create new column from event screen.
* Improved usernames in Event Head dropdown.

= 2.0.2 =
* Minor bugfixes and improvements.

= 2.0.1 =
* Bug fix: fixed an issue with template override.

= 2.0.0 =
* We improved compatibility with your theme styles in this update. If you still stick to a previous version, simply change the template mode option in the plugin settings.
* Added the ability to set font size for timetable shortcode so you can make your text bigger or smaller.

= 1.1.6 =
* Bug fix: fixed an issue with empty rows.

= 1.1.5 =
* Bug fix: fixed an issue with post view in search results.

= 1.1.4 =
* Improved compatibility with Polylang plugin.

= 1.1.3 =
* Fixed an issue with categories filter in widget.

= 1.1.2 =
* Fixed an issue with posts order.

= 1.1.0 =
* Improved events sorting.
* Minor bugfixes and improvements.

= 1.0.7 =
* Improved events and columns sorting by date.
* Comments section added to event.
* Minor bugfixes and improvements.

= 1.0.6 =
* Fixed an issue in column view.

= 1.0.5 =
* Improved compatibility with IE10+

= 1.0.4 =
* Minor bugfixes and improvements.

= 1.0.3 =
* Minor bugfixes and improvements.
