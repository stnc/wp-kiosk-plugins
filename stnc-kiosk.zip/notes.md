
özel front dakı tarıhı de duzeltsın



https://github.com/notifirehq/notifire/tags  tag ve versiyonlama için buna bak 

notice gibi bişey eklemnecek onunla resimin olması gereken boyut uyarısı verecek yada sidebar falan bı yere eklenebilir 

sidebar metabox isimleri değişecek 

çoklu dil eklenebilir 

apiyi kapatma olayi olsun 

slide genel gorunme suresi 

slidelar hangi tipe gore siralansin tarih id 

hava durumu gecis suresi 

6 gunluk hava durumu olsun mu 

doviz altin sekmesini gosterme onun yerine 6 gunluk hava durumu olsun 

dolar 
euro
altin
ceyrek altin


++  unutma video ise onun testinin yapilmasi lazim 

