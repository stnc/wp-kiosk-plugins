# wp-kiosk-plugins
wordpress kiosk tv 
