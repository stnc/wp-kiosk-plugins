<?php
/*
Plugin Name:Chrom Themes Staff
Plugin URI:			
Description: Staff Members plugin for the Nucleon theme.	
Version: 1.11.97
Author: Chrom Themes
Text Domain: chrom_staff
Domain Path: /languages/
*/ 
include ('chrom_staff_file.php');