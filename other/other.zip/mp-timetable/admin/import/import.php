<h1><? _e('Import', 'mp-timetable') ?></h1>
<?php wp_import_upload_form('admin.php?import=mptt-importer&amp;step=1'); ?>